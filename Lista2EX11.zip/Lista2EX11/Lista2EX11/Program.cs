﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using System.Threading.Tasks;

namespace Lista2EX11
{
    internal class Program
    {
        static void Main(string[] args)
        {

            double P1;

            double resultado;

            Console.WriteLine("Digite o valor da nota da P1:");
            P1 = double.Parse(Console.ReadLine());
            Console.WriteLine();



            resultado = P1 + 5 / 2;

            if (resultado >= 5)

                Console.WriteLine("Aprovado");

            else

                Console.WriteLine("Reprovado");
            Console.WriteLine(" Os pontos extras que você precisava era:{0}", resultado);

           
        }

    }
}